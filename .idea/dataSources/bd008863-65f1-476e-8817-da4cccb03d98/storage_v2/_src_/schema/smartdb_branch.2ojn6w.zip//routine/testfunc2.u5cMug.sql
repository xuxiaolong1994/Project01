create function testfunc2()
  returns varchar(100)
  BEGIN
	#Routine body goes here...
	SET @te1 = (SELECT DATABASE());
	RETURN @te1;
END;

