create function testfunc1()
  returns int(10)
  BEGIN
	#Routine body goes here...
	SET @te=(SELECT DATABASE());
	RETURN @te;
END;

