create function F_GETCHILDRENLIST(nodeId varchar(200))
  returns varchar(21845)
  BEGIN
    DECLARE nodeIdStr VARCHAR(21845);
    DECLARE allNodeIdStr VARCHAR(21845);
    SET nodeIdStr = '';
    SET allNodeIdStr = CAST(nodeId AS CHAR);
    WHILE allNodeIdStr IS NOT NULL DO
        IF nodeIdStr = '' THEN
            SET nodeIdStr = CONCAT(nodeIdStr, allNodeIdStr);
        ELSE
            SET nodeIdStr = CONCAT(nodeIdStr, ',', allNodeIdStr);
        END IF;
        SELECT GROUP_CONCAT(T_ORGANIZATION.ORGANIZATION_ID)
        INTO allNodeIdStr
        FROM T_ORGANIZATION 
        WHERE FIND_IN_SET(T_ORGANIZATION.`PARENT_ORGANIZATION_ID`,allNodeIdStr) > 0;
    END WHILE;
        -- SET nodeIdStr = CONCAT(nodeIdStr, '\'');
    RETURN nodeIdStr;
END;

