create function F_GETCHILDRENLISTNEW(ID varchar(21845))
  returns varchar(21845)
  BEGIN  
  DECLARE allNodeIdStr VARCHAR(21845); 
  SET ID = CAST(id AS CHAR);
  SELECT GROUP_CONCAT(T.ID) INTO allNodeIdStr FROM(
SELECT 
		organization_id AS ID,
		PARENT_ORGANIZATION_ID AS PID,
		levels AS levels, 
		CONCAT(paths,',',organization_id) AS paths
FROM (
    SELECT 
				organization_id,
				PARENT_ORGANIZATION_ID,
				@le:= IF (
				PARENT_ORGANIZATION_ID = 0 ,0,  
         IF( LOCATE( CONCAT('|',PARENT_ORGANIZATION_ID,':'),@pathlevel)   > 0  ,      
                  SUBSTRING_INDEX( SUBSTRING_INDEX(@pathlevel,CONCAT('|',PARENT_ORGANIZATION_ID,':'),-1),'|',1) +1
        ,@le+1) ) levels
     , @pathlevel:= CONCAT(@pathlevel,'|',organization_id,':', @le ,'|') pathlevel
      , @pathnodes:= IF( PARENT_ORGANIZATION_ID =0,',0', 
           CONCAT_WS(',',
           IF( LOCATE( CONCAT('|',PARENT_ORGANIZATION_ID,':'),@pathall) > 0  , 
               SUBSTRING_INDEX( SUBSTRING_INDEX(@pathall,CONCAT('|',PARENT_ORGANIZATION_ID,':'),-1),'|',1)
              ,@pathnodes ) ,PARENT_ORGANIZATION_ID  ) )paths
    ,@pathall:=CONCAT(@pathall,'|',ORGANIZATION_ID,':', @pathnodes ,'|') pathall 
        FROM  T_ORGANIZATION, 
    (SELECT @le:=0,@pathlevel:='', @pathall:='',@pathnodes:='') vv
    ORDER BY  PARENT_ORGANIZATION_ID,ORGANIZATION_ID
    ) src
) T WHERE FIND_IN_SET(ID,T.PATHS) > 0; 
  RETURN allNodeIdStr;  
END;

