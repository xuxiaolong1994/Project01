create function F_GETPARENTSLIST(nodeId varchar(200))
  returns varchar(1000)
  BEGIN
  DECLARE resultStr VARCHAR(1000);
  DECLARE tempStr VARCHAR(1000);  
  SET resultStr = '$';
  SET tempStr = cast(nodeId as char);
  WHILE tempStr is not null DO SET resultStr = concat(resultStr, ',', tempStr);  
SELECT GROUP_CONCAT(T_ORGANIZATION.PARENT_ORGANIZATION_ID)
INTO tempStr
FROM T_ORGANIZATION
WHERE T_ORGANIZATION.PARENT_ORGANIZATION_ID <> T_ORGANIZATION.ORGANIZATION_ID
AND FIND_IN_SET(T_ORGANIZATION.ORGANIZATION_ID, tempStr) > 0;
  END WHILE;
  RETURN resultStr;
END;

